-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 29, 2013 at 06:07 PM
-- Server version: 5.5.25
-- PHP Version: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `vezba3`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `customerID` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(20) NOT NULL,
  `surname` varchar(20) NOT NULL,
  `address` varchar(30) NOT NULL,
  `town` varchar(20) NOT NULL,
  `postcode` varchar(12) NOT NULL,
  `email` varchar(20) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  PRIMARY KEY (`customerID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customerID`, `firstName`, `surname`, `address`, `town`, `postcode`, `email`, `mobile`) VALUES
(1, 'Fred', 'Flintstone', '43 Rubble St', 'Bedrock', 'E3 4ER', 'fred@flintstones.com', '07456765345'),
(2, 'Peter', 'Griffin', '23 Spooner St', 'Qauhog', 'N4 5RT', 'peter@griffins.com', '07654335648'),
(3, 'Marge', 'Simpson', '43 Evergreen Terrace', 'Springfield', 'W3 2ER', 'homer@simpsons.com', '07456557875'),
(7, 'Jagger', 'Brown', '12 Saint St', 'Dalston', 'E8 3WE', 'jagger@brown.com', '07866444567'),
(5, 'Bart', 'Simpson', '43 Evergreen Terrace', 'Springfield', 'W3 2ER', 'bart@simpsons.com', '07654335648'),
(6, 'John', 'Smith', '34 Driver Terrace', 'Dalston', 'E8 4RT', 'john@smith.com', '07866445643'),
(8, 'Mary', 'Jones', '434 Smith St', 'Dalston', 'E8 3WQ', 'mary@jones.com', '07866444342'),
(9, 'Dave', 'Evans', '52 Smith St', 'Dalston', 'E8 3RE', 'dave@evans.com', '07654335093'),
(10, 'Rob', 'Davies', '37 Smith St', 'Dalston', 'E8 3WT', 'rob@davies.com', '07866444385'),
(11, 'Judy', 'Martin', '93 Smith St', 'Dalston', 'E8 3RQ', 'judy@martin.com', '07654335361'),
(12, 'Vlada', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `orderID` int(11) NOT NULL AUTO_INCREMENT,
  `productID` int(11) NOT NULL,
  `customerID` int(11) NOT NULL,
  `storeID` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`orderID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderID`, `productID`, `customerID`, `storeID`, `date`, `quantity`) VALUES
(1, 7, 1, 1, '2012-02-07 12:48:09', 3),
(2, 8, 2, 2, '2012-02-07 12:48:09', 1),
(3, 7, 3, 3, '2012-02-07 12:48:23', 1),
(4, 9, 2, 4, '2012-02-07 12:48:23', 2);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `productID` int(11) NOT NULL AUTO_INCREMENT,
  `productType` varchar(15) NOT NULL,
  `productName` varchar(30) NOT NULL,
  `price` float NOT NULL,
  `description` varchar(255) NOT NULL,
  `imageName` varchar(30) NOT NULL,
  `partNum` varchar(10) NOT NULL,
  PRIMARY KEY (`productID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`productID`, `productType`, `productName`, `price`, `description`, `imageName`, `partNum`) VALUES
(1, 'Hammer', 'Ball Pane Hammer', 14.99, 'Hardened steel head, steel handle', 'hammer1.jpg', 'PH001'),
(5, 'Drill', 'Hand Drill - Electric', 29.99, 'Hand Power Tool, 240V', 'drill1.png', 'PD001'),
(4, 'Hammer', 'Claw Hammer', 10.99, 'Steel claw head, wooden handle', 'hammer2.jpg', 'PH002'),
(7, 'Drill', 'Bench Drill - Electric', 49.99, 'Bench Drill, 240V', 'drill2.jpg', 'PD002'),
(8, 'Hammer', 'Wooden Mallet', 9.99, 'Wooden head, wooded handle', 'hammer3.png', 'PH003'),
(9, 'Saw', 'Small Hand Saw', 12.99, 'Multi-purpose hand saw', 'saw1.jpg', 'PS001'),
(10, 'Saw', 'Hack Saw', 14.99, 'Hack saw with 3 replacement blades', 'saw2.jpg', 'PS002'),
(11, 'Saw', 'Bush Saw', 19.99, 'Rugged saw for outdoor purposes', 'saw3.png', 'PS003'),
(12, 'Hand Tools', 'Spanner Set', 14.99, '16 piece spanner set', 'hand1.jpg', 'PT001'),
(13, 'Hand Tools', 'Screwdriver set', 12.99, '12 piece screwdriver set', 'hand2.jpg', 'PT002');

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

DROP TABLE IF EXISTS `stores`;
CREATE TABLE `stores` (
  `storeID` int(11) NOT NULL AUTO_INCREMENT,
  `locator` varchar(20) NOT NULL,
  `address` varchar(30) NOT NULL,
  `town` varchar(15) NOT NULL,
  `contact` varchar(30) NOT NULL,
  `phone` varchar(15) NOT NULL,
  PRIMARY KEY (`storeID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `stores`
--

INSERT INTO `stores` (`storeID`, `locator`, `address`, `town`, `contact`, `phone`) VALUES
(1, 'Dalston', '192 Smith St', 'Dalston', 'Mike Julian', '02085456785'),
(2, 'Holborn1', '23 Rally St', 'Holborn', 'Dave Mallett', '02075446785'),
(3, 'Holborn2', '19 Dave St', 'Holborn', 'Mary Walker', '02076783489'),
(4, 'Balham', '1 Wills St', 'Balham', 'Dean Stevens', '02085221185'),
(5, 'Putney', '22 Heaven St', 'Putney', 'Mark O''Malhi', '02076783409');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
